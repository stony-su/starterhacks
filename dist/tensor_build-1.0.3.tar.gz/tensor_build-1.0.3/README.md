# starterhacks
 starterhacks project july 27th
 
## Installation

You can install the package using pip:

```bash
pip install tensorflow_buidler
