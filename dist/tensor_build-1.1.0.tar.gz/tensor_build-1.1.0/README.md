# starterhacks
Starterhacks project july 27th
Created by Darren Su, Eddie Bian, Kahan Shah, and Richard Tuo. Please like and subscribe! Don't forget to comment and subscribe next time
 
## Installation

You can install the package using pip:

```bash
pip install tensorflow_builder
```

## Usage
import tensorflow_builder
tensorflow_builder.build()
